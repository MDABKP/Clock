package com.example.clockwidget

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TextView(this).apply {
            text = getString(R.string.how_to_add)
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(64, 64, 64, 64)
        }
        setContentView(tv)
    }
}
