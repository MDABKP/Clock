# Digital Clock Widget (Android)

## GitHub Actions দিয়ে APK বানানো
1. GitHub-এ নতুন repository খুলুন (যেমন `clock-widget`)।
2. এই ফোল্ডারের **সব ফাইল** (লুকানো `.github` ফোল্ডারসহ) repository-র মূল জায়গায় আপলোড করুন।
3. repository-র **Actions** ট্যাবে যান → **Build APK** workflow চলবে (না চললে "Run workflow" চাপুন)।
4. সবুজ টিক এলে সেই run খুলে নিচে **Artifacts** থেকে `ClockWidget-debug-apk` ডাউনলোড করুন (zip খুললে `app-debug.apk`)।
5. ফোনে APK ইনস্টল করুন (Settings → Install unknown apps চালু করতে হতে পারে)।
6. অ্যাপটি একবার খুলুন, তারপর হোম স্ক্রিনে লং-প্রেস → Widgets → **Digital Clock**।

## Android Studio দিয়ে
ফোল্ডারটি Open করে Run চাপুন।
